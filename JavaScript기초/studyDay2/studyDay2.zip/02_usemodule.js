
var calc =  require('./02_module');
console.log("모듈로 분리한 호출결과 =",calc.add(10,10));
